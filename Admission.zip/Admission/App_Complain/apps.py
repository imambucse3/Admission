from django.apps import AppConfig


class AppComplainConfig(AppConfig):
    name = 'App_Complain'

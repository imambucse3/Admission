from django.apps import AppConfig


class SubjectAppConfig(AppConfig):
    name = 'Subject_App'

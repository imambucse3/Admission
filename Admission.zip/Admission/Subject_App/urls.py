from django.urls import path
from Subject_App import views

app_name = 'Subject_App'

urlpatterns = [
    path('', views.Subject_Choice.as_view(), name='subject'),
    path('science/', views.science, name='sciences'),
    path('showlist/', views.showlist, name='showlist'),
    path('com/', views.com, name='com'),
     path('arts/', views.art, name='art'),
    
]
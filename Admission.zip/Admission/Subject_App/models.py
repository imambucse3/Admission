from django.db import models

# Create your models here.


class Unit_Name(models.Model):
    title = models.CharField(max_length=20)

    def __str__(self):
        return self.title

    class Meta:
        verbose_name_plural = "Unit_Names"

class Faculty(models.Model):
    name = models.CharField(max_length=264)
    unit= models.ForeignKey(Unit_Name, on_delete=models.CASCADE, related_name='unit')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = "Facultys"
        
 
class Science(models.Model):
    name = models.CharField(max_length=200, null=True)
    
 
    
    
class City(models.Model):
    name = models.CharField(max_length=30)
   
    def __str__(self):
        return self.name
     
    class Meta:
        db_table = 'map'
        
class Commerce(models.Model):
    name = models.CharField(max_length=30)
   
    def __str__(self):
        return self.name
     
    class Meta:
        db_table = 'mapcom'
        
class Arts(models.Model):
    name = models.CharField(max_length=30)
   
    def __str__(self):
        return self.name
     
    class Meta:
        db_table = 'maparts'

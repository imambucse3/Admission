from django.shortcuts import render

# Import views
from django.views.generic import ListView

# Models
from Subject_App.models import Faculty,Science,City

# Mixin
from django.contrib.auth.mixins import LoginRequiredMixin

from django.shortcuts import render, redirect 
from django.http import HttpResponse
from django.forms import inlineformset_factory
# Create your views here.

from django.shortcuts import render
from Subject_App.models import City,Commerce,Arts
# Create your views here.



class Subject_Choice(ListView):
    model = Faculty
    template_name = 'Subject_App/home.html'
    
    
def science(request):
    
    sciences = Science.objects.all()
    print(science)

    return render(request, 'Subject_App/science.html', {'sciences':sciences})


 
def showlist(request):
    results=City.objects.all
    print(results)
    return render(request, "Subject_App/science.html",{"showcity":results})

def com(request):
    results1=Commerce.objects.all
    print(results1)
    return render(request, "Subject_App/commerce.html",{"showcity":results1})

def art(request):
    results2=Arts.objects.all
    print(results2)
    return render(request, "Subject_App/arts.html",{"showcity":results2})
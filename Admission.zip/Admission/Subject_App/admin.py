from django.contrib import admin
from Subject_App.models import Faculty,Unit_Name,Science,Commerce,Arts,City

# Register your models here.

admin.site.register(Faculty)
admin.site.register(Unit_Name)
admin.site.register(Science)

admin.site.register(Commerce)
admin.site.register(Arts)
admin.site.register(City)
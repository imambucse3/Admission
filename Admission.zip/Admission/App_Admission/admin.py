from django.contrib import admin
from App_Admission.models import Faculty, Unit_Name

# Register your models here.

admin.site.register(Faculty)
admin.site.register(Unit_Name)

from django.apps import AppConfig


class AppAdmissionConfig(AppConfig):
    name = 'App_Admission'

from django.urls import path
from App_Admission import views

app_name = 'App_Admission'

urlpatterns = [
    path('', views.Home.as_view(), name='home'),
    path('product/<pk>/', views.Detail.as_view(), name='detail'),
]
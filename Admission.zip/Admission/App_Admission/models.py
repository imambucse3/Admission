from django.db import models

# Create your models here.


class Unit_Name(models.Model):
    title = models.CharField(max_length=20)

    def __str__(self):
        return self.title

    class Meta:
        verbose_name_plural = "Unit_Names"

class Faculty(models.Model):
    name = models.CharField(max_length=264)
    unit= models.ForeignKey(Unit_Name, on_delete=models.CASCADE, related_name='unit')
    price = models.FloatField()

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = "Facultys"

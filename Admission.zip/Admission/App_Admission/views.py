from django.shortcuts import redirect, render

# Import views
from django.views.generic import ListView, DetailView

# Models
from App_Admission.models import Faculty

from django.shortcuts import render, get_object_or_404, redirect

# Mixin
from django.contrib.auth.mixins import LoginRequiredMixin
# Create your views here.



class Home(ListView):
    model = Faculty
    template_name = 'App_Admission/home.html'

class Detail(LoginRequiredMixin, DetailView):
    model = Faculty
    template_name = 'App_Admission/detail.html'
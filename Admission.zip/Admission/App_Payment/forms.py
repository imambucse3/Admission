from django import forms
from App_Payment.models import BillingApply



class BillingForm(forms.ModelForm):
    class Meta:
        model = BillingApply
        fields = ['address','gstroll', 'gstmark','upazila','district', 'city', 'country','zipcode']
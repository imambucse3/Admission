from django.contrib import admin

from App_Payment.models import BillingApply

# Register your models here.

admin.site.register(BillingApply)

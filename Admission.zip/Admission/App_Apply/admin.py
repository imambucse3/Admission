from django.contrib import admin
from App_Apply.models import Applicated, Apply
from App_Apply.models import Applicated, Apply

# Register your models here.

admin.site.register(Applicated)
admin.site.register(Apply)

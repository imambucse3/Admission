from django.shortcuts import render, get_object_or_404, redirect

# Authentications
from django.contrib.auth.decorators import login_required

# Model
from App_Apply.models import Applicated, Apply
from App_Admission.models import Faculty
# Messages
from django.contrib import messages
# Create your views here.

@login_required
def add_to_applicated(request, pk):
    item = get_object_or_404(Faculty, pk=pk)
    print("Item")
    print(item)
    order_item = Applicated.objects.get_or_create(item=item, user=request.user, purchased=False)
    print("Order Item Object:")
    print(order_item)
    print(order_item[0])
    order_qs = Apply.objects.filter(user=request.user, applied=False)
    print("Order Qs:")
    print(order_qs)
    #print(order_qs[0])
    if order_qs.exists():
        order = order_qs[0]
        print("If Order exist")
        print(order)
        if order.applyitems.filter(item=item).exists():
            order_item[0].quantity
            order_item[0].save()
            return redirect("App_Admission:home")
        else:
            order.applyitems.add(order_item[0])
            return redirect("App_Admission:home")
    else:
        order = Apply(user=request.user)
        order.save()
        order.applyitems.add(order_item[0])
        return redirect("App_Admission:home")
    
@login_required
def cart_view(request):
    applicated = Applicated.objects.filter(user=request.user, purchased=False)
    applys = Apply.objects.filter(user=request.user, applied=False)
    if applicated.exists() and applys.exists():
        apply = applys[0]
        return render(request, 'App_Apply/cart.html', context={'carts':applicated, 'order':apply})
    else:
        messages.warning(request, "You don't have any faculty in your Applicated!")
        return redirect("App_Admission:home")

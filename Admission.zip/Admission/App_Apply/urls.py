from django.urls import path
from App_Apply import views

app_name = 'App_Apply'

urlpatterns = [
    path('add/<pk>/', views.add_to_applicated, name="add"),
    path('apply/', views.cart_view, name="cart"),
   
]
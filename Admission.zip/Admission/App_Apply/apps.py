from django.apps import AppConfig


class AppApplyConfig(AppConfig):
    name = 'App_Apply'

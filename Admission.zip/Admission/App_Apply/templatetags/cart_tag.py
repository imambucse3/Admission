from django import template
from App_Apply.models import Apply

register = template.Library()


@register.filter
def cart_total(user):
    order = Apply.objects.filter(user=user, applied=False)

    if order.exists():
        return order[0].applyitems.count()
    else:
        return 0